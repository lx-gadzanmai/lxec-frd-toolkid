<h1 align="center">乐信电商前端工具集</h1>

## 状态栏按钮

在乐信gitlab里打开项目.

![](https://coss-ec.fenqile.com/ecproduct201/M00/ex/20240614192159-c44b4641-7dca-4b32-912a-2333340cd73c.jpg)

## 命令打开项目 gitlab

`shift + ctrl + p` 打开命令行，输入 `gitlab`

![](https://coss-ec.fenqile.com/ecproduct201/M00/ex/20240617113603-0786591e-0d37-4915-b9c5-806594c707b6.jpg)

## 快速添加带颜色背景的 console.log

在编辑器中鼠标框选变量，按下快捷键 `shift + ctrl + l` 可自动插入带颜色背景的特殊 console.log

![](https://coss-ec.fenqile.com/ecproduct201/M00/ex/20240617114426-96a7add5-1429-449a-a3bf-fea454329867.jpg)

![](https://coss-ec.fenqile.com/ecproduct201/M00/ex/20240617114405-7b87cba0-a82b-4db7-b2d1-d54c238b6d84.jpg)

按下快捷键 `shift + ctrl + d` 可在目标编辑器中快速删除带颜色背景的特殊 console.log

## License

[MIT](https://github.com/lx-gadzanmai/lxec-frd-toolkid/blob/HEAD/LICENSE) License © 2024 [Gadzan](https://github.com/gadzan)
